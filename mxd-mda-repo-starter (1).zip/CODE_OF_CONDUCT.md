# Code of Conduct

Be respectful. No harassment, hate speech, or personal attacks.  
Assume good intent, stay constructive, and keep feedback actionable.  
Violations may result in warnings, temporary bans, or removal.

If you experience or witness unacceptable behavior, email conduct@mxd-mda.example.
